	$("#General").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='General.html'
	})
		$("#Memory").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Memory.html'
	})
		$("#Storage").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Storage.html'
	})
		$("#Networking").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Networking.html'
	})
		$("#Console").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Console.html'
	})
		$("#Snapshots").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Snapshots.html'
	})
		$("#Search").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Search.html'
	})
		$("#Performance").bind('click',function(){
		var aaa=window.parent.document.getElementById("iframe");
		aaa.src='Performance.html'
	})