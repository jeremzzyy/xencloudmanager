              	var flag
              $(".info").bind('click',function(e){
              		if($(e.target).attr('class')=='li' && e.target.getElementsByTagName("ul").length ==0){
              				  $(e.target).css({
							  "color":"white",
							  "background-color":"#5f67b5",
							  'border':'1px dashed white'
							  });
							  $(flag).css({
							  "color":"#5f67b5",
							  "background-color":"white",
							  'border':''
							  });
							   flag=e.target
	        				　 document.getElementById("iframe").src='General.html'
						}
              })